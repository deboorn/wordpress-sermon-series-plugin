<?php


class SermonPlugin_Controller_Admin extends SermonPlugin_Controller_Base
{


}